using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EMVisual : MonoBehaviour
{
    public float timestep;
    public float lengthScale;
    public int sliceRender;

    float time; int frameCount;

    public Vector3Int resolution;
    Vector3Int threadGroups => new Vector3Int(Mathf.CeilToInt(resolution.x / 10f), Mathf.CeilToInt(resolution.y / 10f), Mathf.CeilToInt(resolution.z / 10f));
    int elements => resolution.x * resolution.y * resolution.z;
    public RenderTexture screenImage;
    public ComputeShader shader;

    int ComputeDerivatives => shader.FindKernel("ComputeDerivatives");
    int Initialization => shader.FindKernel("Initialization");
    int Transfer => shader.FindKernel("Transfer");
    int EvolveEM => shader.FindKernel("EvolveEM");
    int Integral => shader.FindKernel("Integral");
    int Print => shader.FindKernel("Print");

    ComputeBuffer newDerivatives;
    ComputeBuffer oldDerivatives;
    ComputeBuffer potentialFields;
    ComputeBuffer integral;
    Vector4[] finalIntegrals;

    // Start is called before the first frame update
    void Start()
    {
        potentialFields = new ComputeBuffer(elements, sizeof(float) * 16);
        oldDerivatives = new ComputeBuffer(elements, sizeof(float) * 16);
        newDerivatives = new ComputeBuffer(elements, sizeof(float) * 16);
        integral = new ComputeBuffer(1024, sizeof(float) * 4);
        finalIntegrals = new Vector4[1024];

        screenImage = new RenderTexture(resolution.x * 8, resolution.y * 8, 0) { enableRandomWrite = true };
        screenImage.Create();

        Init();
        time = 0f; frameCount = 0;
        InitializationKernel();
    }

    private void OnDestroy()
    {
        screenImage.Release();
        DestroyImmediate(screenImage, true);
        potentialFields.Dispose();
        oldDerivatives.Dispose();
        newDerivatives.Dispose();
        integral.Dispose();
    }

    private void Init()
    {
        shader.SetInt("slice", sliceRender);
        shader.SetInt("threadNumberOfElements", Mathf.CeilToInt(elements / 1024f));
        shader.SetInts("resolution", resolution.x, resolution.y, resolution.z);
        shader.SetFloat("lengthScale", lengthScale);
        shader.SetFloat("timestep", timestep);
    }

    void InitializationKernel()
    {
        shader.SetFloats("recenter", 0f, 0f, 0f, 0f);
        shader.SetBuffer(Initialization, "potentialFields", potentialFields);
        shader.Dispatch(Initialization, threadGroups.x, threadGroups.y, threadGroups.z);
    }
    void ComputeDerivative()
    {
        shader.SetBuffer(ComputeDerivatives, "newDerivatives", newDerivatives);
        shader.SetBuffer(ComputeDerivatives, "oldDerivatives", oldDerivatives);
        shader.SetBuffer(ComputeDerivatives, "potentialFields", potentialFields);
        shader.Dispatch(ComputeDerivatives, threadGroups.x, threadGroups.y, threadGroups.z);
    }
    void EvolveEMField()
    {
        shader.SetFloat("time", time);
        shader.SetBuffer(EvolveEM, "newDerivatives", newDerivatives);
        shader.SetBuffer(EvolveEM, "oldDerivatives", oldDerivatives);
        shader.SetBuffer(EvolveEM, "potentialFields", potentialFields);
        shader.Dispatch(EvolveEM, threadGroups.x, threadGroups.y, threadGroups.z);
    }
    void TransferData()
    {
        shader.SetBuffer(Transfer, "potentialFields", potentialFields);
        shader.Dispatch(Transfer, threadGroups.x, threadGroups.y, threadGroups.z);
    }
    void IntegrateAll()
    {
        shader.SetBuffer(Integral, "integral", integral);
        shader.SetBuffer(Integral, "potentialFields", potentialFields);
        shader.Dispatch(Integral, 1, 1, 1);

        integral.GetData(finalIntegrals);
        Vector4 final = Vector4.zero;
        for (int i = 0; i < 1024; i++)
            final += finalIntegrals[i];
        final *= Mathf.Ceil(elements / 1024f) / ((float)elements);
        shader.SetVector("recenter", final * .3333333333f);
    }
    void PrintImage()
    {
        shader.SetBuffer(Print, "newDerivatives", newDerivatives);
        shader.SetTexture(Print, "Result", screenImage);
        shader.Dispatch(Print, Mathf.CeilToInt(resolution.x / 32f), Mathf.CeilToInt(resolution.x / 32f), 1);
    }

    private void OnRenderImage(RenderTexture source, RenderTexture destination)
    {
        Graphics.Blit(screenImage, destination);
    }

    // Update is called once per frame
    void Update()
    {
        Init();
        time += timestep; frameCount++;
        for (int i = 0; i < 2; i++)
        {
            ComputeDerivative();
            EvolveEMField();
        }
        if (frameCount % 3 == 0)
            IntegrateAll();
        TransferData();
        PrintImage();
    }
}
